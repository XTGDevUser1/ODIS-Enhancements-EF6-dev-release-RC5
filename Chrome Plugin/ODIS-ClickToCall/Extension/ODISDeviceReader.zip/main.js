chrome.runtime.sendMessage({greeting: "hello"}, function(response) {
  
});

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
	  console.log(request);
	  document.getElementById('odisfield').value = request.text;
  });


