DECLARE @parentID INT 
DECLARE @recordID INT 

DECLARE @accounting UNIQUEIDENTIFIER
DECLARE @accountingMGR  UNIQUEIDENTIFIER

SET @accounting = (select R.RoleId from aspnet_Roles R join
aspnet_Applications  A
ON R.ApplicationId = A.ApplicationId
WHERE A.ApplicationName = 'DMS'
AND R.RoleName ='Accounting')

SET @accountingMGR = (select R.RoleId from aspnet_Roles R join
aspnet_Applications  A
ON R.ApplicationId = A.ApplicationId
WHERE A.ApplicationName = 'DMS'
AND R.RoleName ='AccountingMgr')


SET @parentID = (SELECT ID FROM Securable WHERE FriendlyName = 'MENU_TOP_CLIENT')
SET @recordID = (SELECT ID FROM Securable WHERE FriendlyName = 'BUTTON_POST_INVOICES ')

IF NOT EXISTS (SELECT * FROM Securable WHERE FriendlyName = 'BUTTON_POST_INVOICES')
BEGIN
      INSERT INTO Securable Values('BUTTON_POST_INVOICES',@parentID,NULL) 
      SET @recordID = SCOPE_IDENTITY()
END

IF NOT EXISTS (SELECT * FROM AccessControlList WHERE SecurableID = @recordID)
BEGIN
      INSERT INTO AccessControlList VALUES(@recordID,@accounting,3)
      INSERT INTO AccessControlList VALUES(@recordID,@accountingMGR,3)
END

--PHANI
IF NOT EXISTS (SELECT * FROM CommentType WHERE Name = 'ServiceRequest')
BEGIN
INSERT INTO CommentType VALUES('ServiceRequest', 'Service Request',1,1)
END